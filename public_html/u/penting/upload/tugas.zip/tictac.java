package tictactoe;



	import java.io.BufferedReader;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.util.concurrent.TimeUnit;



	public class tictac {
		//variables
				static BufferedReader in = new BufferedReader (new InputStreamReader(System.in));// variable
				static String[][] tictactoePrint = {{" "," "," "},{" "," "," "},{" "," "," "}};//array
				static String pemainPertama = "Pemain Pertama";//variabel nama Pemain Pertama
				static String pemainKedua = "Pemain Kedua";//variabel nama Pemain Kedua				
				
				
				public static void main(String[] args) throws IOException{
					printAwal();//memanggil printAwal
				}
				
				/*tampilan menu*/
				private static void printAwal() throws IOException{
					String input;//variable input
					
					
					System.out.println("===============================");
					System.out.println("Selamat Datang Tic Tac Toe Game");
					System.out.println("===============================");
					
					System.out.println("1.Pemain Pertama\n2.Pemain Kedua");
					System.out.println("***************************");
					
					input =in.readLine();//input
					
					//pilih user
					while (!input.equals("1") && !input.equals("2")){
						System.out.println("Pilihan Salah, Cek pilihan anda lagi");
						input = in.readLine();
					}
					
					System.out.println("***************************");
					System.out.println();
					
					//memanggil proses method
					if (input.equals("1"))
						pemainPertama();
					if (input.equals("2"))
						pemainKedua();
					
				}
				
			
				
				
				private static void printboard(){
					
					System.out.println("TIC TAC TOE");
					System.out.println("===========");
					System.out.println(" 1   2   3");
					System.out.println("===========");
					System.out.println(" "+tictactoePrint[0][0]+" | "+tictactoePrint[0][1]+" | "+tictactoePrint[0][2] +"  1");
					System.out.println("___________");
					System.out.println(" "+tictactoePrint[1][0]+" | "+tictactoePrint[1][1]+" | "+tictactoePrint[1][2] +"  2");
					System.out.println("___________");
					System.out.println(" "+tictactoePrint[2][0]+" | "+tictactoePrint[2][1]+" | "+tictactoePrint[2][2] +"  3");
					System.out.println("\n===========");
				}	
				
				
				//pecahan
						static String pieceGiliran = "x";//variable melacak x/y pice
						static String pieceCheck = "x";//cek kapan giliran tempat x/y piece
						static String winPiece;//cek pemenang pice

				/*output benar dan salah */
				
				private static boolean pilihpemenang (String piece, String[][]tictactoePrint){
					
					//serangkaian perintah jika menang dan salah
					if (tictactoePrint[0][0].equals(piece) && tictactoePrint[0][1].equals(piece) &&  tictactoePrint[0][2].equals(piece) ){
						return true;}//benar jika cocok}
					else if(tictactoePrint[1][0].equals(piece) && tictactoePrint[1][1].equals(piece) &&  tictactoePrint[1][2].equals(piece)){
						return true;}
					else if(tictactoePrint[2][0].equals(piece) && tictactoePrint[2][1].equals(piece) &&  tictactoePrint[2][2].equals(piece)){
						return true;}
					else if(tictactoePrint[0][0].equals(piece) && tictactoePrint[1][0].equals(piece) &&  tictactoePrint[2][0].equals(piece)){
						return true;}
					else if(tictactoePrint[0][1].equals(piece) && tictactoePrint[1][1].equals(piece) &&  tictactoePrint[2][1].equals(piece)){
						return true;}
					else if(tictactoePrint[0][2].equals(piece) && tictactoePrint[1][2].equals(piece) &&  tictactoePrint[2][2].equals(piece)){
						return true;}
					else if(tictactoePrint[0][0].equals(piece) && tictactoePrint[1][1].equals(piece) &&  tictactoePrint[2][2].equals(piece)){
						return true;}
					else if (tictactoePrint[0][2].equals(piece) && tictactoePrint[1][1].equals(piece) &&  tictactoePrint[2][0].equals(piece)){
						return true;}
					else 
						return false;
					
					

				}

				/*pemenang game*/
				
				private static void pemainPertama() throws IOException{
					
					boolean checking = false;//jika mendapatkan pemenang
					String pilihan = "1";//variable memainkan game ulang
					
					
					while (!pilihan.equals("2")){
						
						clearBoard();//membersihkan board awal 
						
					System.out.println("==========================");
					System.out.println("Jadi, kamu pemain pertama Hi?");
					System.out.println("==========================");
					
					System.out.println("Siapa Nama Kamu ?: ");
					pemainPertama = in.readLine();//masukan
					
					System.out.println("Ok jadi Permainan Dimisalkan, "+pemainPertama+" akan menjadi X dan komputer menjadi O");
					
					try {
						TimeUnit.MILLISECONDS.sleep(800);
						System.out.println("Mari Bermain.");
						TimeUnit.MILLISECONDS.sleep(800);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//board tidak penuh
					while (checkBoardifFull(tictactoePrint)){
						
						berpikir();
						
						randomAI();
						printboard();
						checking = pilihpemenang("o", tictactoePrint);
						
						if (checking){
							pieceGiliran = "o";
							break;
						
						}
						
						inputCoordinate();
						checking = pilihpemenang("x", tictactoePrint);
						printboard();
						
						// break
						if (checking)
							break;
						
						
					}
					
					//cek
					if (checking == true){
						if (pieceGiliran.equals("o")){
							System.out.println("ops, kamu kalah, komputer menang!");
						}
						
						else if (pieceGiliran.equals("x")){
							System.out.println(pemainPertama+" Selamat kamu menang!");
						}
					}
					
					else
						System.out.println("ini hadiah!");
					
					//menanyakan user
							System.out.println("==========================================");
							System.out.println("Ingin Bermain Ulang?\n1.ya\n2.tidak");
							System.out.println("==========================================");
							pilihan = in.readLine();// input
							//valid
							while (!pilihan.equals("1") && !pilihan.equals("2")){
								
							System.out.println("Kesalahan, Ingin Bermain Ulang??\n1.ya\n2.tidak");	
							pilihan = in.readLine();
							} 
							
							}
							//selesai
							System.out.println("Terima Kasih Telah Bermain. Bye!");
							
				}
				
				/* *Output:2 pemain tic tac toe game*/
				
				private static void pemainKedua() throws IOException{
					Boolean checking = false;//cek jika salah satu pemenang
					String pilihan = "1";//variable pilihan memainkan lagi			

					while (!pilihan.equals("2")){
						
					clearBoard();//main ulang membersihkan
					
					//jargon
					System.out.println("==========================");
					System.out.println("Jadi, kamu ingin bermain berdua hi?");
					System.out.println("==========================");
					
					
					System.out.println("Siapa Nama Kamu Pemain Pertama?: ");
					pemainPertama = in.readLine();//input
					
					System.out.println("Siapa Nama Kamu Pemain Kedua?: ");
					pemainKedua = in.readLine();// input
					
					System.out.println("Ok jadi Permainan Dimisalkan, "+pemainPertama+" akan menjadi X dan "+pemainKedua+" komputer menjadi O");
					
					try {
						TimeUnit.MILLISECONDS.sleep(800);
						System.out.println("Mari Bermain.");
						TimeUnit.MILLISECONDS.sleep(800);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//
					printboard();
					
					//board tidak full
					while (checkBoardifFull(tictactoePrint)){
						
						
						turn();
						inputCoordinate();
						
						//cek pemenang
						checking = pilihpemenang(pieceGiliran, tictactoePrint);
						printboard();
						
						// break
						if (checking)
							break;
						
						
					}
					//jika telah mendapatkan pemenang siapa dia
					if (checking == true){
						if (pieceGiliran.equals("x")){
							System.out.println(pemainKedua+" Selamat Kamu Menang!");
						}
						
						else if (pieceGiliran.equals("o")){
							System.out.println(pemainPertama+" Selamat kamu menang!");
						}
					}
					//else let the user know that its a tie
					else
						System.out.println("it�s a tie!");

					//ask user if they want to play again
					System.out.println("==========================================");
					System.out.println("Ingin Bermain Ulang?\n1.ya\n2.tidak");
					System.out.println("==========================================");
					pilihan = in.readLine();//store user input
					//validation
					while (!pilihan.equals("1") && !pilihan.equals("2")){
						
					System.out.println("Kesalahan, Ingin Bermain Ulang??\n1.ya\n2.tidak");	
					pilihan = in.readLine();
					} 
					
					}
					//exit the game
					System.out.println("Terima Kasih Telah Bermain. Bye!");
					
				}
				
				/*Output:menganti pice x to o*/
				
				private static void turn (){
					if (pieceGiliran.equals("x")){
						System.out.println(pemainKedua+"giliran kamu");//giliran
						pieceGiliran = "o";
						pieceCheck = "x";
					}
					
					else if (pieceGiliran.equals("o")){
						System.out.println(pemainPertama+"giliran kamu");//Giliran
						pieceGiliran = "x";
						pieceCheck = "o";
					}
				}
				
			
				
				private static void inputCoordinate() throws IOException {
					String xcoordinate;// variable xcoordinate
					String ycoordinate;//variable y coordinate
					
					
					System.out.println("========================");
					System.out.println("Silakan pilih koordinat x pada papan: ");
					xcoordinate = in.readLine();
					
					//validation
					while (!xcoordinate.equals("1") && !xcoordinate.equals("2") && !xcoordinate.equals("3")){
						System.out.println("Kesalahan, Silakan pilih koordinat x pada papan: ");
						xcoordinate = in.readLine();//
					}

					
					System.out.println("========================");
					System.out.println("Silakan pilih koordinat y pada papan ");
					ycoordinate = in.readLine();//input
					
					// validation
					while (!ycoordinate.equals("1") && !ycoordinate.equals("2") && !ycoordinate.equals("3")){
						System.out.println("kesalahan, Silakan pilih koordinat x pada papan: ");
						ycoordinate = in.readLine();
					}
					
					//mengubah string menjadi dan int untuk dalam indeks array 2d
					int xco = Integer.parseInt(xcoordinate);
					int yco = Integer.parseInt(ycoordinate);
					 
					//a while loop untuk memerika piece
					while (!tictactoePrint[xco-1][yco-1].equals(" ")){
						System.out.println("Tersedia potongan di sana.");
					
						System.out.println("========================");
						System.out.println("Silakan pilih koordinat x pada papan: ");
						xcoordinate = in.readLine();
						//validation
						while (!xcoordinate.equals("1") && !xcoordinate.equals("2") && !xcoordinate.equals("3")){
							System.out.println("Kesalahan, Silakan pilih koordinat x pada papan: ");
							xcoordinate = in.readLine();
						}
						
						
						System.out.println("========================");
						System.out.println("Silakan pilih koordinat y pada papan ");
						ycoordinate = in.readLine();
						//validation
						while (!ycoordinate.equals("1") && !ycoordinate.equals("2") && !ycoordinate.equals("3")){
							System.out.println("Kesalahan, Silakan pilih koordinat x pada papan: ");
							ycoordinate = in.readLine();
						}
						//menjadi bilangan bulat baru
						xco = Integer.parseInt(xcoordinate);
						yco = Integer.parseInt(ycoordinate);
					}
					//memanggil variable placepiece
					placePiece(xcoordinate, ycoordinate);
				}
				
				/*Menggunakan parameter koordinat yang diturunkan, menggunakannya sebagai nilai indeks dan menetapkan elemen ke bagian yang sesuai
				 *Output: menetapkan posisi yang sesuai suatu bagian*/
				
				private static void placePiece(String xcoordinate, String ycoordinate){
					//jika koordinat yang diturunkan sama 
					if (xcoordinate.equals("1") && ycoordinate.equals("1")){	
						tictactoePrint[0][0] = pieceGiliran;	
					}
					
					else if (xcoordinate.equals("1") && ycoordinate.equals("2")){	
						tictactoePrint[0][1] = pieceGiliran;	
					}
					else if (xcoordinate.equals("1") && ycoordinate.equals("3")){	
						tictactoePrint[0][2] = pieceGiliran;	
					}
					
					if (xcoordinate.equals("2") && ycoordinate.equals("1")){	
						tictactoePrint[1][0] = pieceGiliran;	
					}
					
					else if (xcoordinate.equals("2") && ycoordinate.equals("2")){	
						tictactoePrint[1][1] = pieceGiliran;	
					}
					else if (xcoordinate.equals("2") && ycoordinate.equals("3")){	
						tictactoePrint[1][2] = pieceGiliran;	
					}
					
					if (xcoordinate.equals("3") && ycoordinate.equals("1")){	
						tictactoePrint[2][0] = pieceGiliran;	
					}
					
					else if (xcoordinate.equals("3") && ycoordinate.equals("2")){	
						tictactoePrint[2][1] = pieceGiliran;	
					}
					else if (xcoordinate.equals("3") && ycoordinate.equals("3")){	
						tictactoePrint[2][2] = pieceGiliran;	
					}
					else  
						System.out.println("kosong yang ditambahkan.");
					
				}
				
				/*mengembalikan false atau true pada kondisi*/
				
				private static boolean checkBoardifFull(String[][] tictactoePrint){
					
					boolean check = false;//variabel bollean menyimpan kondisi
					
					//mencari ruang kosong
					for (int i = 0; i <3; i++){
						for (int j = 0; j<3; j++){
							if (tictactoePrint[i][j].equals(" "))//jika ruang kosong
								check = true;//jika benar
						}
					}
					
					return check;//cek bollean
				}
				
				/*reset*/
				
				private static void clearBoard(){
					//reset
					for (int i= 0; i<3; i++){
						for (int j= 0; j<3;j++){
							tictactoePrint[i][j] = " ";
						}
					}
					//reset
					pemainPertama = "Pemain Pertama";
					pemainKedua = "Pemain Kedua";
					//reset
					pieceGiliran = "o";
					pieceCheck = "x";
				}
				

				
				private static void randomAI (){

					//analisa 0-2 variabel
					int xCoordinate = (int) (Math.random()*3+0);
					int yCoordinate = (int) (Math.random()*3+0);

					while (!tictactoePrint[xCoordinate][yCoordinate].equals(" ")){
						xCoordinate = (int) (Math.random()*3+0);
						yCoordinate = (int) (Math.random()*3+0);
					}

					//index array
					tictactoePrint[xCoordinate][yCoordinate] = "o";
				
				}
				
				
				
				private static void berpikir(){
					
					//method waktu giliran
					try {
						TimeUnit.MILLISECONDS.sleep(1000);
						System.out.println("komputer memilih");
						TimeUnit.MILLISECONDS.sleep(800);
						System.out.print(".");
						TimeUnit.MILLISECONDS.sleep(800);
						System.out.print(".");
						TimeUnit.MILLISECONDS.sleep(800);
						System.out.print(".\n");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

