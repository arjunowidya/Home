import java.util.ArrayList;
import java.util.Scanner;

public class Uno {

	private Card current; // arus kartu / sebelumnya / selanjutnya
	private Deck deck; // the deck of the game
	private ArrayList<Card> tempatkartu; // saat pemain melempar kartu, kartu itu menumpuk di sini. buat dek baru jika dek saat ini kosong
	private int penalty; //ketika wildcard menumpuk hukuman menumpuk.pemain dihukum "penalti" jumlah kartu
	private Scanner pilihan;
	private Player p1,p2; //pemain
	private int memilih; // pemain memilih
	
	public Uno() {
		/*constructor
		 * constructs the game
		 * prepares the game to play
		 */
		deck = new Deck();
		deck.shuffle();
		penalty = 0;
		current = getStartingCard();
		tempatkartu = new ArrayList<Card>();
		tempatkartu.add(current);
		pilihan = new Scanner(System.in);
		p1 = new Player("Pemain 1");
		p2 = new Player("Pemain 2");
		distributecards();
		
	
	}
	
	
	
	public void game() {
			/* this method simulates turns between the two players. when turn is even, player 1 plays and when 
			   turn is odd player 2 plays.
			*/	
		int turn=0;
		while(!gameOver(p1,p2)) {
			if(turn%2==0) {
			playGame(p1);}
			else {
			playGame(p2);}
			turn++;
		}
		
	}
	
	
private void distributecards() {
		//this method distributes cards to the players
		for(int i=0;i<10;i++) {
			
			if(i%2==0) {
				p1.pickCards(deck.getTopCard());
			}
			
			else {
				p2.pickCards(deck.getTopCard());
			}
			
			
		}
	}
	
	
	
	public void playGame(Player p) {
		/*	 this method takes player that is currently playing as an argument.
			 this method contains entire process for the game.
		*/
		
		decorate();
		System.out.println(p+", Giliran Kamu\nKartu Yang Sedang Dimainkan:\n"+current);
		
		decorate();
		showBoard(p);
		decorate();
		
		if(current.isSpecial()) {
			penalty+=current.getValue();
			Card pick;
			if(!canOverride(p)) {
				System.out.println("Kamu tidak punya kartu untuk mengganti kartu khusus ini, terkena sanksi ");
				for(int i=0;i<penalty;i++) {

					if(deck.isEmpty()) {
						deck = new Deck(tempatkartu);
					}
					pick = deck.getTopCard();
					p.pickCards(pick);
					System.out.println("Kamu Memilih: \n"+pick);
					pause();
					
				}
				penalty = 0;
				current = deck.getTopCard();
				System.out.println("Kartu Baru Yang dimainkan: \n"+current);
			}
			
			
			}
			
//		}   
		
		
	
		
	
		if(!hasColor(p) && !hasValue(p) && !hasSpecial(p)) {
				Card pick=null;	
				System.out.println("Kamu tidak punya kartu yang benar untuk dimainkan, Anda harus memilih kartu.");
				while(!hasColor(p) && !hasValue(p) && !hasSpecial(p)) {
					
					pause();
					pick = deck.getTopCard();
					p.pickCards(pick);
					System.out.println("Kamu Memilih:\n"+pick);
					
				}
				
				System.out.println("Kamu Menerima Kartu Yang Benar!");
				pause();
				System.out.println("Kamu memiliki kartu berikut: ");
				p.showCards();
			}
			
	
		
		
		
		System.out.println("Pilih Kartu Kamu:");
		memilih = pilihan.nextInt()-1;
		//System.out.println(pick);
		
		while(!isValidpilihan(p,memilih)) {
			
			System.out.println("Pilihan tidak benar. Silakan pilih kartu yang benar.");
			memilih = pilihan.nextInt()-1;
			
		}
		
		Card play = p.throwCard(memilih	);
		
		p.sayUno();
		current = play;
		tempatkartu.add(current);
		reviveDeck();
	}
	
	
	private void reviveDeck() {
		// TODO Auto-generated method stub
		
	}



	private boolean hasSpecial(Player p) {
		// TODO Auto-generated method stub
		
		for(Card c:p.PlayerCards()) {
			
			if(c.isSpecial()) {
				return true;
			}
			
		}
		
		
		return false;
	}

	private boolean isValidpilihan(Player p,int pilihan) {
		
		/*
		 * checks if the user selection was a valid pilihan or not
		 * to be a valid pilihan: the player must have the card, the card must be either the same color or value as the current card(card in play/previously played card)
		 */
		
		if(pilihan <= p.PlayerCards().size()) {
			//add for special
			
			if(p.PlayerCards().get(pilihan).getColor().equals(current.getColor()) || p.PlayerCards().get(pilihan).getValue()==current.getValue() || p.PlayerCards().get(pilihan).isSpecial()) {
				return true;
			}
			
			
		}
		
		return false;
	}
	
	
	private void pause() {
		/*
		 * creates a pause
		 * asks the user to press enter
		 * purpose is simply to get user engagement
		 */
		System.out.println("tekan enter untuk lanjut..");
		pilihan.nextLine();
		
	}
	
		
	private boolean hasColor(Player p) {
		/*
		 * checks if player has card of the same color as the current card that is being played
		 */
		for(Card c:p.PlayerCards()) {
			
			if(c.getColor().equals(current.getColor())) {
				return true;
			}
			
			
		}
		
		return false;
	}
	
	private boolean hasValue(Player p) {  
		/*
		 * checks if the player has the card of the same value as the current that is being played. 
		 */
		
		for(Card c:p.PlayerCards()) {
			
			if(c.getValue()==current.getValue()) {
				
				return true;
				
			}
		}
		
		return false;
	}
	
	
	private boolean canOverride(Player p) {
		
		/*
		 * checks if player has a wild card (special card)
		 * special cards can be played when you don't have a card with the same color or the value of the card that is being currently played
		 * if the current card is a special card, then player must have a special card with the same or greater value to play.
		 */
		for(Card c:p.PlayerCards()) {
			
			if(c.isSpecial()) {
				if(c.getValue() >= current.getValue()) {
					return true;
				}
			}
		}
		
		
		return false;
	}
	
	private void decorate() {
		/*
		 * draws asterik lines
		 */
		
		
		System.out.println("<-------------------------------------------------->");
	}
	
	
	
	
	private Card getStartingCard() {
		
		/*
		 * gets a valid starting card.
		 * starting card cannot be a special card
		 */
		
		Card temp = deck.peek();
		while(temp.isSpecial()) {
			deck.shuffle();
			temp = deck.peek();
		}
		
		temp = deck.getTopCard();
		return temp;
	}
	
	
	


public boolean gameOver(Player p1,Player p2) {
	
	if(p1.hasWon()) {
		System.out.println("--------------------------------------------------");
		System.out.println("Pemain 1 Menang");
		System.out.println("--------------------------------------------------");
		return true;
	}
	
	else if(p2.hasWon()) {
		System.out.println("**************************************************");
		System.out.println("Pemain 2 Menang");
		System.out.println("**************************************************");
		return true;
	}
	
	return false;
}

public void showBoard(Player p) {
	
	if(p.toString().equals("Pemain 1")) {
		System.out.println("                Pemain 1");
		p1.showCards();
		p2.hideCards();
		System.out.println("                Pemain 2");
		System.out.println("");
	}
	else {
		
		System.out.println("                Pemain 1");
		p1.hideCards();
		p2.showCards();
		System.out.println("                Pemain 2");
		System.out.println("");
		
	}
	
}



}
