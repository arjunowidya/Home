
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 *Main functions just runs the game by calling the game method. game mthod resides in the Uno class.
		 */
	
		Uno game = new Uno();
		
		game.game();
		
		
	}

}
